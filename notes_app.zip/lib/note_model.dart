class NoteClass{
  String title;
  String note;
  NoteClass(this.title,this.note);
}